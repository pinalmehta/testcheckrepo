var config = {
    map: {
        '*': {
            bizkickowlcarousel: 'Fantasyworld_Fwtheme/js/owl.carousel',
        }
    }
};