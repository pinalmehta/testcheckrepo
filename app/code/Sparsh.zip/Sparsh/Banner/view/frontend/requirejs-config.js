var config = {
    map: {
        '*': {
            "slick": 'Sparsh_Banner/js/slick',
        }
    }
};
